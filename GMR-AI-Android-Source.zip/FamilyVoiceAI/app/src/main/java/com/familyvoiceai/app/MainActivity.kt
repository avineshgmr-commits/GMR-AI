package com.familyvoiceai.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("gmr_ai", MODE_PRIVATE) }
    private val profiles = mutableListOf<JSONObject>()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selected: JSONObject? = null
    private var tts: TextToSpeech? = null
    private val bg = Color.rgb(15, 20, 38)
    private val panel = Color.rgb(29, 37, 61)
    private val accent = Color.rgb(137, 128, 255)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadProfiles()
        showHome()
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ta", "IN") }

    private fun loadProfiles() {
        profiles.clear()
        val raw = prefs.getString("profiles", "[]") ?: "[]"
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) profiles.add(arr.getJSONObject(i))
    }

    private fun saveProfiles() {
        val arr = JSONArray(); profiles.forEach { arr.put(it) }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(22, 28, 22, 18) }
        val header = TextView(this).apply { text = title; textSize = 25f; setTextColor(white); setTypeface(null, 1); setPadding(0, 8, 0, 18) }
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun text(value: String, size: Float = 15f, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, 1); setPadding(0, 7, 0, 7)
    }

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(white); setBackgroundColor(accent); setOnClickListener { onClick() }
    }

    private fun field(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(white); setHintTextColor(Color.LTGRAY); textSize = 15f
        setPadding(16, 10, 16, 10); setBackgroundColor(panel)
    }

    private fun showHome() {
        base("GMR AI")
        content.addView(text("உங்கள் குடும்பத்தினருக்கான தனிப்பட்ட AI உரையாடல்", 14f, Color.LTGRAY))
        content.addView(text("Family profiles", 18f, white, true))
        if (profiles.isEmpty()) content.addView(text("இன்னும் யாரையும் சேர்க்கவில்லை. முதலில் ஒரு profile உருவாக்குங்கள்.", 14f, Color.LTGRAY))
        profiles.forEach { p ->
            val card = TextView(this).apply {
                text = "${p.optString("name")}  •  ${p.optString("relationship")}\nவயது: ${p.optString("age")}  |  ${p.optString("language", "தமிழ்")}\n${p.optString("personality")}" 
                textSize = 16f; setTextColor(white); setPadding(18, 18, 18, 18); setBackgroundColor(panel)
                setOnClickListener { selected = p; showChat() }
            }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12; content.addView(card, lp)
        }
        content.addView(button("＋ Add family member") { showAddProfile() })
        content.addView(button("AI connection settings") { showSettings() })
        content.addView(text("குறிப்பு: இது AI உருவகப்படுத்தல்; உண்மையான குடும்ப உறுப்பினர் பேசுவது அல்ல.", 12f, Color.LTGRAY))
    }

    private fun showAddProfile() {
        base("Add family member")
        val name = field("பெயர்")
        val relation = field("உறவு (அப்பா / அம்மா / சகோதரி)")
        val age = field("வயது", "")
        val language = field("மொழி", "தமிழ்")
        val personality = field("குணம் மற்றும் பேசும் விதம்")
        val details = field("வாழ்க்கை விவரங்கள் / தெரிந்த தகவல்கள்")
        val memories = field("பகிர்ந்த குடும்ப நினைவுகள்")
        val consent = CheckBox(this).apply { text = "இந்த நபரின் குரல் மாதிரியைப் பயன்படுத்த அவருடைய அனுமதி உள்ளது (பின்னர் voice cloning-க்கு)"; setTextColor(white) }
        listOf(name, relation, age, language, personality, details, memories).forEach { content.addView(it); addSpace(8) }
        content.addView(consent)
        content.addView(button("Save profile") {
            if (name.text.isBlank() || relation.text.isBlank() || age.text.isBlank()) { toast("பெயர், உறவு, வயது தேவை"); return@button }
            val p = JSONObject().put("name", name.text.toString()).put("relationship", relation.text.toString())
                .put("age", age.text.toString()).put("language", language.text.toString())
                .put("personality", personality.text.toString()).put("details", details.text.toString())
                .put("memories", memories.text.toString()).put("voiceConsent", consent.isChecked)
            profiles.add(p); saveProfiles(); showHome()
        })
        content.addView(button("Cancel") { showHome() })
    }

    private fun showChat() {
        val p = selected ?: return showHome()
        base("Talking with ${p.optString("name")}")
        content.addView(text("AI simulation • ${p.optString("relationship")} • Age ${p.optString("age")}", 13f, Color.LTGRAY))
        val transcript = TextView(this).apply { text = "வணக்கம்! பேசத் தொடங்கலாம்.\n"; textSize = 16f; setTextColor(white); setPadding(14, 14, 14, 14); setBackgroundColor(panel) }
        content.addView(transcript)
        val input = field("தமிழில் உங்கள் கேள்வியை எழுதுங்கள்")
        content.addView(input)
        content.addView(button("🎙 Speak") { startSpeech(input) })
        content.addView(button("Send") {
            val msg = input.text.toString().trim(); if (msg.isEmpty()) return@button
            transcript.append("\nநீங்கள்: $msg\n")
            input.setText("")
            val reply = callBackend(p, msg) { answer -> runOnUiThread {
                transcript.append("\nAI (${p.optString("name")}): $answer\n")
                tts?.speak(answer, TextToSpeech.QUEUE_ADD, null, "family_reply")
            } }
            if (reply) transcript.append("AI பதில் பெறப்படுகிறது...\n") else transcript.append("AI server அமைக்கப்படவில்லை. Settings-ல் HTTPS backend URL சேர்க்கவும்.\n")
        })
        content.addView(button("Back to family") { showHome() })
    }

    private fun callBackend(profile: JSONObject, message: String, callback: (String) -> Unit): Boolean {
        val endpoint = prefs.getString("backend_url", "") ?: ""
        if (endpoint.isBlank()) return false
        thread {
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                    setRequestProperty("Content-Type", "application/json"); doOutput = true
                }
                val payload = JSONObject().put("profile", profile).put("message", message).put("simulation", true)
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                val answer = JSONObject(body).optString("reply", "AI பதில் கிடைக்கவில்லை.")
                callback(answer); conn.disconnect()
            } catch (e: Exception) { callback("இணைப்பு பிழை: ${e.localizedMessage ?: "unknown"}") }
        }
        return true
    }

    private fun showSettings() {
        base("AI connection")
        content.addView(text("HTTPS backend URL", 14f, Color.LTGRAY))
        val url = field("https://your-server.example/chat", prefs.getString("backend_url", "") ?: "")
        content.addView(url)
        content.addView(text("API secret-ஐ APK-க்குள் நேரடியாக வைக்க வேண்டாம். பாதுகாப்பான server மூலம் AI provider-ஐ அழைக்க வேண்டும்.", 13f, Color.LTGRAY))
        content.addView(button("Save") {
            val v = url.text.toString().trim()
            if (v.isNotEmpty() && !v.startsWith("https://")) { toast("HTTPS URL மட்டும் பயன்படுத்தவும்"); return@button }
            prefs.edit().putString("backend_url", v).apply(); showHome()
        })
        content.addView(button("Back") { showHome() })
    }

    private fun startSpeech(target: EditText) {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "தமிழில் பேசுங்கள்")
            }
            startActivityForResult(i, 44)
        } catch (_: Exception) { toast("இந்த மொபைலில் Speech Recognition கிடைக்கவில்லை") }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) {
                // Find the visible chat input and populate it.
                findEditText(root)?.setText(words)
            }
        }
    }

    private fun findEditText(v: View): EditText? {
        if (v is EditText) return v
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) findEditText(v.getChildAt(i))?.let { return it }
        return null
    }
    private fun addSpace(h: Int) { val v = View(this); content.addView(v, LinearLayout.LayoutParams(1, h)) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
