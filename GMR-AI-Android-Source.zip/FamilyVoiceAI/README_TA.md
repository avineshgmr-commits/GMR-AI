# GMR AI — Android starter project (v0.1.0)

**Application name:** GMR AI  
**Android application ID:** `com.gmr.ai`

இது GMR AI குடும்ப உரையாடல் செயலிக்கான ஆரம்ப Android Studio project. குடும்ப உறுப்பினர் profile உருவாக்குதல், வயது/உறவு/குணம்/குடும்ப நினைவுகள் சேமித்தல், தமிழ் Speech-to-Text input, Android Text-to-Speech output, மற்றும் HTTPS AI backend-க்கு request அனுப்பும் அடிப்படை வசதிகள் உள்ளன.

## தற்போதைய செயல்பாடுகள்
- குடும்ப உறுப்பினர் பெயர், உறவு, வயது, மொழி, குணம், விவரங்கள், நினைவுகள் சேர்த்தல்.
- Profile-களை இந்த Android சாதனத்தில் SharedPreferences மூலம் சேமித்தல்.
- தமிழ் Speech Recognition input மற்றும் Android Tamil Text-to-Speech output.
- Settings-ல் HTTPS AI backend URL அமைத்தல்.

## முக்கியமான வரம்புகள்
- இந்த ZIP-ல் **APK binary இல்லை**; Android SDK/Gradle build environment-ல் compile செய்த பிறகே APK கிடைக்கும்.
- உண்மையான AI பதில்களுக்கு HTTPS backend தேவை. Backend `POST` JSON `{ "profile": {...}, "message": "...", "simulation": true }` ஏற்று `{ "reply": "..." }` திருப்ப வேண்டும்.
- உண்மையான voice cloning மற்றும் real-time streaming இன்னும் இணைக்கப்படவில்லை. இப்போது Android-ன் சாதாரண Tamil TTS மட்டுமே பதில் பேசும்.
- API keys-ஐ APK-க்குள் hardcode செய்ய வேண்டாம்; server-side-ல் பாதுகாக்கவும்.
- குடும்ப உறுப்பினரின் குரலை clone செய்ய அவர்களின் வெளிப்படையான அனுமதி பெற வேண்டும். இது AI உருவகப்படுத்தல் என்பதை உரையாடலில் தெளிவுபடுத்தவும்.

## APK build செய்வது
1. Android Studio-வில் இந்த project folder-ஐ Open செய்யவும்.
2. Android SDK Platform 35 மற்றும் Android Gradle Plugin தேவைகளை install செய்யவும்.
3. Gradle sync முடிந்ததும் Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Debug APK பொதுவாக `app/build/outputs/apk/debug/app-debug.apk`-ல் கிடைக்கும்.

## கணினி இல்லாமல் Cloud-ல் APK build
Project-ஐ GitHub repository-க்கு upload செய்து `main` branch-க்கு push செய்தால் `.github/workflows/build-apk.yml` workflow APK-ஐ build செய்யும். GitHub → Actions → Build Android APK → workflow run → Artifacts பகுதியில் `gmr-ai-debug-apk` பதிவிறக்கம் செய்யலாம். இது debug APK; Play Store release-க்கு பின்னர் signed release build தேவை.

## அடுத்த கட்டங்கள்
1. பாதுகாப்பான backend (AI model integration + authentication).
2. ஒவ்வொரு profile-க்கும் voice enrollment மற்றும் consent flow.
3. அனுமதியுடன் voice cloning provider integration + streaming audio conversation.
4. Encrypted local profile storage, export/delete controls, app lock.
